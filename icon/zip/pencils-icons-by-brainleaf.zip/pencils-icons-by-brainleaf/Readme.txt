Icons Set by Brainleaf Communication

http://www.brainleaf.eu


TERMS OF USE


**************************
****** YES YOU CAN! ******
**************************

- You can use this set for personal and commercial use.

- No attribution required but a linkback would be appreciated.


***************************
****** NO YOU CAN'T! ******
***************************

- You can't sell this set.

- You can't redistribute this set.


Enjoy!
