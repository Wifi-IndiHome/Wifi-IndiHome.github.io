LICENSE AGREEMENT
=================
 
Please ensure that this document is read carefully and is completely comprehended.
 
On Download of Free ArtistsValley icons from partner websites, you enter into an 
agreement with ArtistsValley, LLC. based on the following conditions.
You should abide by the terms of this license. Any breach of this agreement 
could result in cancellation of privileges that are granted by the license 
and possibly a lawsuit being sort against the offender.
 
 
COPYRIGHTS AND OWNERSHIP
========================
All icons available in the package and those that are downloaded are owned and 
copyrighted licensed property of ArtistsValley,LLC.
 
 
ROYALTY FREE ICONS
==================
The Free Icons license ensures royalty-free usage of ArtistsValley Free icons 
for Personal Use. This enables you to use ArtistsValley icons in different 
websites or other digital media without any additional charges or royalties 
abiding to the terms mentioned in this license.
 
 
REDISTRIBUTION AND USAGE
========================
The icons should not be Copied OR Resold individually OR as any form of any 
independent Package or Collection OR otherwise made available for use or 
detached from a Product, Software Application, or Web Page. The icons should 
not be packaged or sold in any form of individual libraries or stand alone 
products. You would require a special bulk volume license and/or royalty 
agreements to redistribute our icons solely as your product or along with 
your product as an image library or package.

You may include the icons in Web Templates, including those which are web 
based, but not limited to Website Designs and Presentation Templates provided 
proper credit is given to ArtistsValley.com

You may not use, or allow anyone else to use The Icons to create 
Pornographic,Libelous,Obscene, or Defamatory material.
 
 
ICON MODIFICATIONS
==================
The icons that are purchased can be modified in any form and combined 
with existing icons from ArtistsValley,LLC. or any other artworks. 
ArtistsValley,LLC. can provide no guarantee of the outcome of the 
resulting design of icons used and will not be held responsible for 
any negative impacts on the resulting designs made thereof.
 
 
TERMINATION OF USE
==================
ArtistsValley, LLC. has the right to terminate this license with you in 
the case of a breach of these agreements and cannot be held liable to any 
loss or damage caused due to the cancellation of the agreement. 
In the case of termination of the license, all icons have to be deleted 
from every application that its used in. Breach of the license agreement 
terms with ArtistsValley can be engaged in a lawsuit with a possible fine.
 
 
LIMITED WARRANTY
================
All icon files are provided "AS IS" and you agree not to hold ArtistsValley.com 
liable for any damages that may occur during to use, or inability to use, 
icons or image data from ArtistsValley.com. Please review our Refund Policy 
before purchasing our products.
 
 
Changes to License Agreement
============================
We reserve the right to revise and modify the terms of this License Agreement 
at any time. When we make additions to the terms or further clarifications, 
we will revise the "last updated" date at the top of the policy. We encourage 
you to review this agreement whenever you visit ArtistsValley.com.
 
 
Contact
=======
Please feel free to contact us for any queries or clarification required 
on our License Agreement at contact@artistsvalley.com . Your understanding 
of our License Agreement is important and will ensure seamless business with us. 
 
 
ArtistsValley Design Team
=====================
contact@artistsvalley.com
www.ArtistsValley.com