Professional Vista Software icons - Free Samples
================================================

Thank you for downloading our free sample icons.
Please let us know how you like this free set by sending some feedback to contact@artistsvalley.com with the proper subject line. 

Package Contents
================
Professional Business Man Icon
Bluetooth Icon
Certificate Icon 
Web Document Icon
Email Icon

Sizes included: 16x16, 24x24, 32x32, 48x48, 72x72, 128x128, 256x256 
Regular, Hot and Disabled Icon States 
File Formats : BMP, JPG, ICO, PNG, GIF

LICENSE AGREEMENT
=================
This is a legal agreement between you, the purchaser, and ArtistsValley,Inc.. 
By Downloading any Royalty-Free icons from our website you agree to the following: 
All of the icons remain the property of ArtistsValley,Inc.. 
The icons can be used ROYALTY-FREE by the Licensee for any Personal, Commercial Project including Web Design, Software, Application, Advertising, Media 
The license does not permit the following uses: The icon may not be Sub-Licensed, Resold, Rented, OR otherwise made available for use or detached from a Product, Software Application, or Web Page. 
You may include the icons in Web Templates, including those which are web based, but not limited to Website Designs and Presentation Templates provided proper credit is given to ArtistsValley.com 
You may not use, or allow anyone else to use The Icons to create Pornographic,Libelous,Obscene, or Defamatory material. 
All icon files are provided "As is." you agree not to hold ArtistsValley.com liable for any damages that may occur during to use, or inability to use, icons or image data from ArtistsValley.com. 

It would be appreciated if you give ArtistsValley.com credit whereever and whenever necessary.

Enjoy the icons and Have a Great Day!

ArtistsValley Design Team
=====================
contact@artistsvalley.com
www.ArtistsValley.com 